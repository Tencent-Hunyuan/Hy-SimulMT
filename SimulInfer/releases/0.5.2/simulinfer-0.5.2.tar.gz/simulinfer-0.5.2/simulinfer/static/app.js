import {serviceURL, websocketURL} from './urls.js';
const $=id=>document.getElementById(id);
let ws,context,media,node,playingAt=0,busy=false,pendingAudio=null,ttsSources=[],captureFlushed=null;
let settings=null,inputNode=null,mutedNode=null,captureStats=null,captureTimer=null;
function updateCaptureStatus(){
  if(!captureStats||!busy)return;
  const now=performance.now(),s=captureStats;
  if(context?.state==='suspended'&&!s.stopping)context.resume().catch(()=>{});
  const seconds=s.samples/s.rate;
  $('capture-status').hidden=false;
  let message=`已采集 ${seconds.toFixed(1)} 秒 · 服务收到 ${(s.receivedMs/1000).toFixed(1)} 秒 · 已处理 ${(s.processedMs/1000).toFixed(1)} 秒`;
  if(s.stopping)message+=' · 正在处理剩余音频';
  else if(now-s.started>3000&&now-s.lastFrame>3000)message+=' · 麦克风未送出音频，请检查权限并保持页面在前台';
  else if(now-s.lastVoice>3000)message+=' · 声音很小，请检查麦克风';
  else if(seconds*1000-s.receivedMs>5000)message+=' · 音频发送中，请检查网络或等待服务处理';
  else if(s.receivedMs-s.processedMs>5000)message+=' · 模型正在处理，请稍候';
  else if(s.lastAction==='WAIT')message+=' · 等待更多语音';
  $('capture-status').textContent=message;
}
function captureFailed(error){
  fail(error);stopCapture();ws?.close();ws=null;setBusy(false);
}
function sendCaptured(raw){
  if(!captureStats||ws?.readyState!==WebSocket.OPEN)return;
  if(ws.bufferedAmount>1024*1024){captureFailed(Error('网络或模型处理过慢，请结束后重新连接'));return}
  const samples=new Int16Array(raw);let peak=0;
  for(const x of samples)peak=Math.max(peak,Math.abs(x));
  const now=performance.now();captureStats.samples+=samples.length;captureStats.lastFrame=now;
  if(peak>98)captureStats.lastVoice=now;
  ws.send(raw);
}

function defaultModel(){return settings?.defaults.model_type}
function cadenceAvailable(){return settings?.response_mode_available?.[defaultModel()]!==false}
function showModel(mode){
  $('source-panel').hidden=mode!=='source_target';
  const name=settings?.model_labels?.[mode]||'';
  $('model-info').textContent=`当前模型：${name} · ${mode==='source_target'?'自动显示源文和译文':'仅显示译文'}`;
}
function updateCadence(){
  const available=cadenceAvailable();
  $('response-mode').disabled=busy||!settings||!available;
  $('cadence-help').textContent=available?'推荐使用标准模式，每1600ms送入模型。短分块模式首块1600ms、后续800ms，供实验比较；更短分块不保证更快输出。':'当前上游服务自行控制分块模式。';
}
async function initialize(){
  try{
    const response=await fetch(serviceURL('config'),{cache:'no-store'});
    if(!response.ok)throw Error(`读取服务配置失败（HTTP ${response.status}）`);
    const data=await response.json();
    if(!data.defaults||!data.modes?.includes(data.defaults.model_type))throw Error('服务配置无效，请检查部署地址');
    if(!['standard','short_chunk'].includes(data.defaults.response_mode))throw Error('页面与后端版本不一致，请重启服务后刷新页面');
    settings=data;
    $('response-mode').value=settings.defaults.response_mode;
    $('vad').checked=settings.defaults.vad;$('tts').checked=settings.defaults.tts;
    $('mock').hidden=!settings.mock;
    $('voice-field').hidden=!!settings.tts_clone_source;
    $('tts-label').textContent=settings.tts_clone_source?'克隆音色并朗读译文':'朗读译文';
    showModel(defaultModel());updateCadence();setBusy(false);$('status').textContent='已就绪';
  }catch(e){fail(e);setBusy(false)}
}
function fail(e){$('error').hidden=false;$('error').textContent=e.message||String(e);$('status').textContent='请求失败';}
function setBusy(value){busy=value;for(const id of ['upload','mic','response-mode','direction','vad','tts','voice','file'])$(id).disabled=!settings||value||(id==='response-mode'&&!cadenceAvailable())||(id==='vad'&&!settings.vad_available)||(id==='tts'&&!settings.tts_available);$('stop').disabled=!value||!ws;}
async function prepare(){
  $('error').hidden=true;$('source').textContent='';$('translation').textContent='';$('progress').textContent='';showModel(defaultModel());pendingAudio=null;
  $('tts-history').hidden=true;
  $('input-audio').hidden=true;
  $('capture-status').hidden=true;
  captureStats=null;
  ttsSources.forEach(s=>{try{s.stop()}catch{}});ttsSources=[];
  if(context){await context.close();context=null}
  if($('tts').checked){context=new AudioContext();await context.resume();playingAt=context.currentTime}
}
function decode64(s){const raw=atob(s);return Uint8Array.from(raw,c=>c.charCodeAt(0)).buffer}
function play(raw,sr){
  if(!context)return;
  const view=new DataView(raw),a=new Float32Array(raw.byteLength/2);
  for(let i=0;i<a.length;i++)a[i]=view.getInt16(i*2,true)/32768;
  const buffer=context.createBuffer(1,a.length,sr);buffer.copyToChannel(a,0);
  const source=context.createBufferSource();source.buffer=buffer;source.connect(context.destination);
  playingAt=Math.max(context.currentTime+.03,playingAt);source.start(playingAt);playingAt+=buffer.duration;
  ttsSources.push(source);source.onended=()=>{ttsSources=ttsSources.filter(x=>x!==source)};
}
function handle(e){
  if(e.event==='input_progress'){
    if(captureStats){captureStats.receivedMs=e.received_ms;updateCaptureStatus()}
    return;
  }
  if(e.event==='voice_clone'){
    $('tts-history').hidden=false;$('tts-history').textContent=`已使用输入音色朗读 · ${e.reference_seconds.toFixed(1)}秒参考语音`;
    return;
  }
  if(e.event==='tts_unavailable'){
    $('tts-history').hidden=false;$('tts-history').textContent=e.detail;return;
  }
  if(e.event==='error')throw Error(e.detail||'服务错误');
  if(e.event==='ready'){
    showModel(e.model_type||e.mode||defaultModel());
    if(typeof e.source_text_enabled==='boolean')$('source-panel').hidden=!e.source_text_enabled;
    $('status').textContent='已连接，等待音频…';
    if(e.input_audio){
      const a=e.input_audio;$('input-audio').hidden=false;
      $('input-audio').textContent=a.sample_rate
        ? `输入 ${a.sample_rate} Hz / ${a.channels} 声道 → 模型 ${a.output_sample_rate} Hz / ${a.output_channels} 声道`
        : `文件已解码为 ${a.output_sample_rate} Hz / ${a.output_channels} 声道供模型使用`;
    }
    if(e.tts_enabled){
      const history=e.tts?.continuity;
      $('tts-history').hidden=false;
      $('tts-history').textContent=e.tts?.clone_source?'自动克隆输入音色并朗读译文':history==='paired_reference_audio'||history==='backend_paired_history'
        ? `译音保留前文语音，历史窗口约 ${e.tts.history_window_s} 秒；完整句段与文字成对保留。`
        : history==='backend_session_unverified'?'已连接会话式TTS，后端未声明是否保留前文语音。':'译音独立合成，当前TTS接口不使用前文语音。';
    }
    return;
  }
  if(e.event==='audio'){
    if(e.encoding==='binary-next')pendingAudio=e;
    else play(decode64(e.data),e.sample_rate);
  }
  if(e.event==='chunk'||e.event==='flush'){
    if(captureStats){captureStats.processedMs=e.end_ms||captureStats.processedMs;captureStats.lastAction=e.action;updateCaptureStatus()}
    $('translation').textContent+=e.text||'';$('source').textContent+=e.source_text||'';
    $('progress').textContent=`${((e.end_ms||0)/1000).toFixed(1)}s · ${e.action||'WAIT'}`;
    $('status').textContent=e.text?'正在翻译':'等待更多语音…';
  }
  if(e.event==='done'){
    if(e.full_text!==undefined)$('translation').textContent=e.full_text;
    if(e.source_text!==undefined)$('source').textContent=e.source_text||'';
    if(captureStats){captureStats.receivedMs=e.duration_ms;captureStats.processedMs=e.duration_ms;updateCaptureStatus()}
    const warning=e.complete===false||e.unresolved_audio_ms||e.skipped_untranslated_audio_ms;
    $('status').textContent=warning?'处理结束，部分音频未能翻译':'已完成';
  }
}
$('file').onchange=()=>{const f=$('file').files[0];if(f)$('status').textContent=f.name};
$('upload').onclick=async()=>{
  if(busy||!settings)return;const file=$('file').files[0];if(!file)return fail(Error('请先选择音频文件'));
  setBusy(true);
  try{
    await prepare();$('status').textContent='正在上传…';
    const data=new FormData();data.append('file',file);data.append('direction',$('direction').value);if(cadenceAvailable())data.append('response_mode',$('response-mode').value);data.append('vad',$('vad').checked);data.append('tts',$('tts').checked);data.append('voice',$('voice').value);
    const r=await fetch(serviceURL('translate/stream'),{method:'POST',body:data});if(!r.ok)throw Error(await r.text());
    const reader=r.body.getReader(),decoder=new TextDecoder();let buf='',doneSeen=false;
    while(true){const {value,done}=await reader.read();if(done)break;buf+=decoder.decode(value,{stream:true});
      let pos;while((pos=buf.indexOf('\n\n'))>=0){const item=buf.slice(0,pos);buf=buf.slice(pos+2);for(const line of item.split('\n'))if(line.startsWith('data:')){const e=JSON.parse(line.slice(5));handle(e);if(e.event==='done')doneSeen=true}}}
    if(!doneSeen)throw Error('连接结束但没有收到done');
  }catch(e){fail(e)}finally{setBusy(false)}
};
async function stopCapture(){
  if(captureTimer){clearInterval(captureTimer);captureTimer=null}
  if(node){node.disconnect();node=null}
  if(inputNode){inputNode.disconnect();inputNode=null}
  if(mutedNode){mutedNode.disconnect();mutedNode=null}
  if(media){media.getTracks().forEach(t=>t.stop());media=null}
}
$('mic').onclick=async()=>{
  if(busy||!settings)return;setBusy(true);
  try{
    await prepare();
    if(!navigator.mediaDevices?.getUserMedia)throw Error('麦克风需要localhost或HTTPS安全环境');
    context=context||new AudioContext();await context.resume();
    media=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true}});
    ws=new WebSocket(websocketURL());ws.binaryType='arraybuffer';
    let completed=false;
    const socket=ws;
    const ready=new Promise((resolve,reject)=>{
      ws.onopen=()=>ws.send(JSON.stringify({direction:$('direction').value,...(cadenceAvailable()?{response_mode:$('response-mode').value}:{}),vad:$('vad').checked,input_format:'s16le',input_sample_rate:context.sampleRate,input_channels:1,tts:$('tts').checked,voice:$('voice').value,audio_transport:'binary',input_progress:true}));
      ws.onerror=()=>{const error=Error('WebSocket连接失败，请检查服务地址和代理连接');reject(error);fail(error)};
      ws.onmessage=e=>{try{if(e.data instanceof ArrayBuffer){if(!pendingAudio)throw Error('音频缺少元信息');play(e.data,pendingAudio.sample_rate);pendingAudio=null;return}const d=JSON.parse(e.data);handle(d);if(d.event==='ready')resolve();if(d.event==='done'){completed=true;socket.close();if(ws===socket)ws=null;stopCapture();setBusy(false)}}catch(err){reject(err);fail(err);stopCapture();ws?.close();ws=null;setBusy(false)}};
      ws.onclose=()=>{if(!completed&&ws===socket){const error=Error('WebSocket在结果完成前断开，请重新连接');reject(error);fail(error);stopCapture();ws=null;setBusy(false)}};
    });
    await ready;
    await context.resume();
    if(context.state!=='running')throw Error('浏览器暂停了音频采集，请重新点击开始');
    const now=performance.now();captureStats={samples:0,rate:context.sampleRate,started:now,lastFrame:now,lastVoice:now,receivedMs:0,processedMs:0,lastAction:'',stopping:false};
    if(context.audioWorklet&&typeof AudioWorkletNode!=='undefined'){
      await context.audioWorklet.addModule(serviceURL('static/recorder.js?v=0.5.2'));
      node=new AudioWorkletNode(context,'pcm-recorder');
      node.onprocessorerror=()=>captureFailed(Error('麦克风采集器中断，请重新连接'));
      node.port.onmessage=e=>{
        if(e.data?.event==='flushed'){captureFlushed?.();captureFlushed=null;return}
        sendCaptured(e.data);
      };
    }else{
      node=context.createScriptProcessor(4096,1,1);
      node.onaudioprocess=e=>{
        const source=e.inputBuffer.getChannelData(0),pcm=new Int16Array(source.length);
        for(let i=0;i<source.length;i++)pcm[i]=Math.max(-32768,Math.min(32767,Math.round(source[i]*32768)));
        sendCaptured(pcm.buffer);
      };
    }
    inputNode=context.createMediaStreamSource(media);
    mutedNode=context.createGain();mutedNode.gain.value=0;
    inputNode.connect(node);node.connect(mutedNode).connect(context.destination);
    for(const track of media.getAudioTracks())track.onended=()=>{if(captureStats&&!captureStats.stopping&&busy)captureFailed(Error('麦克风已断开，请检查设备并重新连接'))};
    captureTimer=setInterval(updateCaptureStatus,1000);updateCaptureStatus();
    $('stop').disabled=false;$('status').textContent='正在收音…';
  }catch(e){fail(e);await stopCapture();ws?.close();ws=null;setBusy(false)}
};
$('stop').onclick=async()=>{
  if(captureStats)captureStats.stopping=true;
  $('stop').disabled=true;$('status').textContent='正在收尾并生成剩余语音…';
  try{
    if(node?.port){await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{captureFlushed=null;reject(Error('麦克风尾帧未确认，请重新连接'))},2000);
      captureFlushed=()=>{clearTimeout(timer);resolve()};node.port.postMessage('flush');
    })}
    await stopCapture();if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify({eof:true}));
  }catch(e){fail(e);await stopCapture();ws?.close();ws=null;setBusy(false)}
};

setBusy(false);
await initialize();
