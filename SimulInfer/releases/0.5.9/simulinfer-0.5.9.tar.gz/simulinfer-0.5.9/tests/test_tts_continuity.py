import asyncio
import base64
from dataclasses import replace
import io
import json
from pathlib import Path
import wave

import httpx
import numpy as np
import pytest
import soundfile as sf

from simulinfer.config import Settings, load
from simulinfer.tts import Speech
from simulinfer.tts_history import AudioHistory


def pcm(seconds, rate=24000, value=123):
    return np.full(round(seconds*rate), value, dtype='<i2').tobytes()


def decode_reference(ref):
    raw=base64.b64decode(ref['ref_audio'].split(',',1)[1])
    with wave.open(io.BytesIO(raw)) as f:
        return f.readframes(f.getnframes()),f.getframerate()


def test_history_drops_complete_pairs_and_keeps_long_last_pair():
    h=AudioHistory(10,240)
    h.commit('first',pcm(6),24000,'en','a')
    h.commit('second',pcm(6,value=456),24000,'en','a')
    ref=h.reference('en','a')
    assert ref['ref_text']=='second' and decode_reference(ref)==(pcm(6,value=456),24000)
    h.commit('long',pcm(15),24000,'en','a')
    assert h.seconds==15 and h.reference('en','a')['ref_text']=='long'
    h.commit('new',pcm(1),24000,'en','a')
    assert h.seconds==1 and h.reference('en','a')['ref_text']=='new'


def test_history_language_voice_and_rate_isolation():
    h=AudioHistory()
    h.commit('one',pcm(1),24000,'en','a')
    assert h.reference('zh','a') is None
    h.commit('二',pcm(1),24000,'zh','a')
    assert h.reference('zh','b') is None
    h.commit('三',pcm(1),24000,'zh','b')
    h.commit('四',pcm(1,rate=16000),16000,'zh','b')
    assert h.reference('zh','b')['ref_text']=='四'
    h.commit('too long',pcm(31,rate=16000),16000,'zh','b')
    assert h.reference('zh','b') is None


def test_history_text_and_waveform_order():
    h=AudioHistory()
    h.commit('first,',pcm(1),24000,'en','a')
    h.commit('second',pcm(2,value=456),24000,'en','a')
    ref=h.reference('en','a')
    assert ref['ref_text']=='first, second'
    assert decode_reference(ref)[0]==pcm(1)+pcm(2,value=456)


@pytest.fixture
def omni_settings(tmp_path):
    ref=tmp_path/'reference.wav';sf.write(ref,np.ones(24000,dtype=np.float32)*.02,24000)
    return Settings(tts_backend='vllm_omni',tts_task_type='Base',tts_history_mode='paired',
        tts_reference_audio=str(ref),tts_reference_text='reference words',tts_min_chars=1)


class Fragmented(httpx.AsyncByteStream):
    def __init__(self,raw,error=False):self.raw=raw;self.error=error
    async def __aiter__(self):
        for i in range(0,len(self.raw),333):
            yield self.raw[i:i+333]
        if self.error:raise httpx.ReadError('broken stream')


async def make_speech(settings,responder):
    events=[]
    async def emit(e):events.append(e)
    s=Speech(settings,emit,'zh-en')
    # For session mode the initial open is part of start().
    if settings.tts_backend=='session':
        from unittest.mock import patch
        client=httpx.AsyncClient(transport=httpx.MockTransport(responder))
        with patch('simulinfer.tts.httpx.AsyncClient',return_value=client):await s.start()
    else:
        await s.start();await s.client.aclose()
        s.client=httpx.AsyncClient(transport=httpx.MockTransport(responder))
    return s,events


@pytest.mark.asyncio
async def test_omni_second_request_uses_first_complete_audio_and_text(omni_settings):
    requests=[]
    def respond(req):
        requests.append(json.loads(req.content))
        return httpx.Response(200,headers={'content-type':'audio/pcm','x-audio-sample-rate':'24000','x-audio-channels':'1'},
                              stream=Fragmented(pcm(1,value=len(requests))))
    s,events=await make_speech(omni_settings,respond)
    try:
        await s.text('First sentence,');await s.text('continuing it.');await s.finish()
        assert requests[0]['ref_text']=='reference words'
        assert requests[1]['ref_text']=='First sentence,'
        assert decode_reference(requests[1])==(pcm(1,value=1),24000)
        assert all(r['stream_format']=='audio' and r['stream'] and r['task_type']=='Base' for r in requests)
        assert all('voice' not in r and r['x_vector_only_mode'] is False for r in requests)
        data=b''.join(base64.b64decode(e['data']) for e in events if e['event']=='audio')
        assert data==pcm(1,value=1)+pcm(1,value=2)
        assert s.history.seconds==2 and events[-1]['event']=='tts_done'
    finally:await s.close()
    assert not s.history.entries and s.anchor is None


@pytest.mark.asyncio
async def test_conversations_never_share_history(omni_settings):
    bodies=[]
    def respond(req):
        bodies.append(json.loads(req.content));return httpx.Response(200,content=pcm(.1))
    a,_=await make_speech(omni_settings,respond);b,_=await make_speech(omni_settings,respond)
    try:
        await a.text('A');await a.finish();await b.text('B');await b.finish()
        assert [r['ref_text'] for r in bodies]==['reference words','reference words']
    finally:await a.close();await b.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('kind',['broken','odd','empty','json','sse','wav','rate','stereo'])
async def test_failed_audio_is_not_history(omni_settings,kind):
    def respond(req):
        headers={'content-type':{'json':'application/json','sse':'text/event-stream','wav':'audio/wav'}.get(kind,'audio/pcm')}
        if kind=='rate':headers['x-audio-sample-rate']='16000'
        if kind=='stereo':headers['x-audio-channels']='2'
        data=b'' if kind=='empty' else pcm(.1)+(b'\x00' if kind=='odd' else b'')
        return httpx.Response(200,headers=headers,stream=Fragmented(data,error=kind=='broken'))
    s,_=await make_speech(omni_settings,respond)
    try:
        with pytest.raises((RuntimeError,httpx.ReadError)):
            await s.text('bad');await s.finish()
        assert not s.history.entries
    finally:await s.close()


@pytest.mark.asyncio
async def test_audio_size_limit(omni_settings):
    s,_=await make_speech(replace(omni_settings,tts_max_audio_seconds=1),
                         lambda req:httpx.Response(200,content=pcm(1.1)))
    try:
        with pytest.raises(RuntimeError,match='上限'):await s.text('too long');await s.finish()
        assert not s.history.entries
    finally:await s.close()


@pytest.mark.asyncio
async def test_cancelled_stream_does_not_commit(omni_settings):
    entered=asyncio.Event()
    class Blocked(httpx.AsyncByteStream):
        async def __aiter__(self):
            yield pcm(.1);entered.set();await asyncio.Event().wait()
    s,_=await make_speech(omni_settings,lambda req:httpx.Response(200,stream=Blocked()))
    await s.text('cancelled');await asyncio.wait_for(entered.wait(),2)
    await asyncio.wait_for(s.close(),2)
    assert not s.history.entries


@pytest.mark.asyncio
async def test_session_window_speed_sid_and_cleanup():
    calls=[]
    def respond(req):
        body=json.loads(req.content) if req.method=='POST' else dict(req.url.params)
        calls.append((req.url.path,body))
        if req.url.path=='/session_open':
            return httpx.Response(200,json={'sid':'private-session','sample_rate':24000,'continuity_version':'paired'})
        if req.url.path=='/session_close':return httpx.Response(200,json={'ok':True})
        return httpx.Response(200,content=pcm(.1),headers={'x-sample-rate':'24000'})
    s,events=await make_speech(Settings(tts_backend='session',tts_history_mode='paired',
        tts_history_window_s=8,tts_speed=1.1,tts_min_chars=1),respond)
    await s.text('first');await s.text('second');await s.finish();await s.close();await s.close()
    assert calls[0][1]['window_s']==8 and calls[0][1]['speed']==1.1
    assert [body['sid'] for path,body in calls if path=='/session_say']==['private-session']*2
    assert sum(path=='/session_close' for path,_ in calls)==1
    assert events[-1]['continuity']=='backend_paired_history'


def test_configuration_rejects_unsupported_history_and_speed(omni_settings,tmp_path):
    with pytest.raises(ValueError):Settings(tts_backend='openai',tts_history_mode='paired')
    with pytest.raises(ValueError):Settings(tts_backend='vllm_omni',tts_history_mode='paired')
    with pytest.raises(ValueError):replace(omni_settings,tts_speed=1.1)
    with pytest.raises(ValueError):replace(omni_settings,tts_reference_text='')
    path=tmp_path/'config.toml'
    path.write_text('[models.target_only]\nbackend="mock"\n[tts]\ntts_backend="vllm_omni"\ntts_task_type="Base"\ntts_reference_audio="reference.wav"\ntts_reference_text="words"\n')
    assert load(str(path)).tts_reference_audio==str(tmp_path/'reference.wav')
